# Mechanical reference

**Superseded 2026-09-06:** this file previously described the Rev A / Hammond
1590F design (174 x 174 mm board, four M3 corner mounting holes, DB-25 debug
connectors, 2.8-inch TFT). That design is retired. Everything below describes
**Rev B**, the compact layout `tools/generate_pcb.py` already implements
(dated 2026-07-25) and which the routed board now uses, targeting the
**Hammond 1590XX** enclosure.

Coordinates use the KiCad placement datum near the upper-left as `(0, 0)`.
The board outline spans X=0.0 to 138.0 mm and Y=0.0 to 114.0 mm, with 12 mm
chamfers cut at all four corners for the enclosure's lid-screw posts (raised
from 9 mm on 2026-09-06 — see `enclosure-1590XX-desk-study.md`). Frame
convention: Y=0 faces the REAR wall (SD/USB access), Y=114 the FRONT wall
(line out + 9V), X=0 the LEFT wall (mic + pad toggle), X=138 the RIGHT wall
(volume + phones).

Rev B has no H1-H4 board-mounting holes — the board is carried entirely by
its own wall-mounted connectors and switches, not corner screws.

## TFT mounting holes

All holes below are 3.2 mm nominal M3 non-plated mounting holes, positioned
around the LCDWiki MSP3520 3.5-inch module footprint.

| Ref | X (mm) | Y (mm) | Purpose |
|---|---:|---:|---|
| H5 | 25.50 | 10.50 | TFT nominal upper-left |
| H6 | 118.80 | 10.50 | TFT nominal upper-right |
| H7 | 25.50 | 61.84 | TFT nominal lower-left |
| H8 | 118.80 | 61.84 | TFT nominal lower-right |

The hole pattern is 93.3 x 51.34 mm (the module itself is 98.3 x 56.34 mm).
Verify the actual screen before drilling the lid.

## Principal component origins

Positions below were read directly from the live, routed
`QuadPreRecorder.kicad_pcb` on 2026-09-06. Wall assignment is the design
intent documented in `tools/generate_pcb.py`; treat orientation as
directional until confirmed against the real part body and a printed drill
template — this table has not yet been re-verified against a physical 1590XX
box (see `enclosure-stackup-and-templates.md`).

| Ref | X (mm) | Y (mm) | Rot | Wall | Function |
|---|---:|---:|---:|---|---|
| J2 | 4.00 | 74.00 | 270 | Left | Ambisonic mic RJ45 (Amphenol RJHSE-5380), port ~flush with wall |
| SW1 | 2.20 | 40.00 | 0 | Left | PAD -10 dB toggle |
| RV1 | 132.00 | 82.00 | 180 | Right | 10 kA dual-gang headphone volume, shaft toward +X |
| J5 | 133.50 | 41.00 | 270 | Right | 1/8 in binaural headphone out |
| J1 | 108.00 | 105.80 | 0 | Front | 9 V DC barrel in |
| J4 | 22.00 | 97.00 | 270 | Front (top side) | 1/4 in binaural line out |
| J6 | 82.00 | 6.00 | 90 | Rear, internal | Analog test header, 2x13 2.54 mm (replaces the old panel DB-25) |
| J7 | 82.00 | 12.50 | 90 | Rear, internal | Digital test header, 2x13 2.54 mm (replaces the old panel DB-25) |
| U8 | 60.00 | 62.50 | 0 | Bottom side | Teensy 4.1; SD/USB access at the rear wall near X=69 |
| J3 | 113.35 | 63.00 | 270 | — | MSP3520 TFT 14-pin header |
| SW2 | 40.75 | 71.00 | 0 | Top (lid) | Record start/stop pushbutton, plunger at (47, 73.5) |
| SW3 | 61.50 | 71.00 | 0 | Top (lid) | Master gain encoder (Alps EC11E), shaft at (69, 73.5) |
| SW4 | 91.00 | 73.50 | 0 | Top (internal — no lid hole) | TFT menu 5-way nav switch (Alps SKQUCAA010), stem at (91, 73.5); setup control with the lid off, navigation is touch + SW3 push |

Before drilling the Hammond box, print the top and bottom PDFs at 100%, fit
the bare PCB, and transfer the actual connector/shaft centers. The STEP file
(once regenerated for this layout) is the source for CAD interference checks;
the table above is not a panel template.
